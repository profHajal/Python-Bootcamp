n = int(input())
sum = 0
for n in range(n,2):
  sum = sum + n
print(sum)
  